const AGM_INIT_NUM = 10;
const AG_MAX = 100;
const AG_MOV_CTRL = 1.0;
var PERFORMANCE_MODE = false;
